
class Animal {
    public void fazerBarulho() {
        System.out.println("Animal fazendo barulho");
    }
}

class Cachorro extends Animal {
    
    public void fazerBarulho() {
        System.out.println("Cachorro fazendo barulho");
    }
}


class Gato extends Animal {
    public void fazerBarulho() {
        System.out.println("Gato fazendo barulho");
    }
}

