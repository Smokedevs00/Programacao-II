
interface Movel {
    void mover();
}

class Carro implements Movel {
    @Override
    public void mover() {
        System.out.println("Carro se movendo");
    }
}

