public class Principal {
    
 public static void main (String[] a) {
    Carro meuCarro = new Carro();
meuCarro.mover(); 
 }

}
