
interface Recurso {
    void alocar();
    void liberar();
}


abstract class RecursoBase implements Recurso {
    private boolean alocado = false;

    @Override
    public void alocar() {
        if (!alocado) {
            alocado = true;
            System.out.println(getClass().getSimpleName() + " alocado com sucesso.");
        } else {
            System.out.println(getClass().getSimpleName() + " já está alocado.");
        }
    }

    @Override
    public void liberar() {
        if (alocado) {
            alocado = false;
            System.out.println(getClass().getSimpleName() + " liberado com sucesso.");
        } else {
            System.out.println(getClass().getSimpleName() + " não está alocado.");
        }
    }
}


class SalaDeReuniao extends RecursoBase {
  
}

class Laptop extends RecursoBase {

}

class Projetor extends RecursoBase {
    
}


class GerenciadorDeRecursos {
    public void alocarRecurso(Recurso recurso) {
        recurso.alocar();
    }
}


class Empresa {
    public static void main(String[] args) {
        GerenciadorDeRecursos gerenciador = new GerenciadorDeRecursos();

        SalaDeReuniao sala = new SalaDeReuniao();
        Laptop laptop = new Laptop();
        Projetor projetor = new Projetor();

    
        gerenciador.alocarRecurso(sala);
        gerenciador.alocarRecurso(laptop);
        gerenciador.alocarRecurso(projetor);
        gerenciador.alocarRecurso(sala);
        gerenciador.alocarRecurso(laptop);

        sala.liberar();
        laptop.liberar();
    }
}
