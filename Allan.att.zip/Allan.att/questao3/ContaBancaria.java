public class ContaBancaria {
    private double saldo;

   
    public ContaBancaria(double saldoInicial) {
        saldo = saldoInicial;
    }

  
    public void depositar(double valor) {
        if (valor > 0) {
            saldo += valor;
            System.out.println("Depósito de " + valor + " realizado com sucesso.");
        } else {
            System.out.println("Valor de depósito inválido. O valor deve ser maior que zero.");
        }
    }

    public void sacar(double valor) {
        if (valor > 0 && valor <= saldo) {
            saldo -= valor;
            System.out.println("Saque de " + valor + " realizado com sucesso.");
        } else {
            System.out.println("Valor de saque inválido ou saldo insuficiente.");
        }
    }

   
    public double getSaldo() {
        return saldo;
    }

    public static void main(String[] args) {
        ContaBancaria conta = new ContaBancaria(2000.0); 

        
        conta.depositar(500.0);
        conta.sacar(200.0);
        conta.sacar(1500.0); 

      
        System.out.println("Saldo atual da conta: " + conta.getSaldo());
    }
}
