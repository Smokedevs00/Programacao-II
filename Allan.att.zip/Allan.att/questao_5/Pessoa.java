
public class Pessoa {
    protected String nome;
    protected int idade;

    
    public Pessoa(String nome, int idade) {
        this.nome = nome;
        this.idade = idade;
    }

 
    public String getNome() {
        return nome;
    }

    public int getIdade() {
        return idade;
    }
}


public class Estudante extends Pessoa {
   
    public Estudante(String nome, int idade) {
        super(nome, idade);
        
    }

    public static void main(String[] args) {

   Estudante estudante = new Estudante("João", 20);
   String nomeDoEstudante = estudante.getNome();
   int idadeDoEstudante = estudante.getIdade();

   System.out.println("Nome do estudante: " + nomeDoEstudante);
   System.out.println("Idade do estudante: " + idadeDoEstudante);
 
    }
}
