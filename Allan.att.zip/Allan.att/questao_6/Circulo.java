public class Circulo {
    private double raio;

    // Construtor
    public Circulo(double raio) {
        this.raio = raio;
    }

  
    public double calcularArea() {
        return 3.14* raio * raio;
    }

  
    public double getRaio() {
        return raio;
    }

    public static void main(String[] args) {
        Circulo circulo = new Circulo(7.0);

        double area = circulo.calcularArea();
        System.out.println("A área do círculo é: " + area);

        double raio = circulo.getRaio();
        System.out.println("Raio do círculo: " + raio);
    }
}
