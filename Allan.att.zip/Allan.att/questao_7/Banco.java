public class Banco {
 
    private static final double positiva = 0.03; 

   
    private static final double negativa = 0.10; 

 
    public static double calculaTaxaJuros(double saldo) {
        if (saldo >= 0) {
            return saldo * positiva;
        } else {
            return saldo * negativa;
        }
    }

    public static void main(String[] args) {
        double saldoPositivo = 1000.0;
        double saldoNegativo = -500.0;

        double jurosPositivos = Banco.calculaTaxaJuros(saldoPositivo);
        double jurosNegativos = Banco.calculaTaxaJuros(saldoNegativo);

        System.out.println("Saldo Positivo: " + saldoPositivo);
        System.out.println("Taxa de Juros para Saldo Positivo: " + jurosPositivos);

        System.out.println("Saldo Negativo: " + saldoNegativo);
        System.out.println("Taxa de Juros para Saldo Negativo: " + jurosNegativos);
    }
}
