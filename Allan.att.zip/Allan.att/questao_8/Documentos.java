
interface Imprimivel {
    void imprimir();
}


class Documento implements Imprimivel {
    private String conteudo;

   
    public Documento(String conteudo) {
        this.conteudo = conteudo;
    }

    @Override
    public void imprimir() {
        System.out.println("Imprimindo documento:\n" + conteudo);
    }
}


class Foto implements Imprimivel {
    private String descricao;

   
    public Foto(String descricao) {
        this.descricao = descricao;
    }

    @Override
    public void imprimir() {
        System.out.println("Imprimindo foto:\n" + descricao);
    }



    public static void main(String[] args) {
        Imprimivel documento = new Documento("Este é um documento de texto.");
        Imprimivel foto = new Foto("Uma linda paisagem.");

        documento.imprimir();
        foto.imprimir();
    }
}

