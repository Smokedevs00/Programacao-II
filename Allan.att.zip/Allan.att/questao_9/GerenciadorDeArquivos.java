public class GerenciadorDeArquivos {
   
    public static void lerArquivo(String nomeArquivo) {
        System.out.println("Lendo o arquivo: " + nomeArquivo);
       
        System.out.println("Conteúdo do arquivo:");
        System.out.println("Este é o conteúdo do arquivo " + nomeArquivo);
    }

    public static void main(String[] args) {
        String nomeDoArquivo = "exemplo.txt";
        GerenciadorDeArquivos.lerArquivo(nomeDoArquivo);
    }
}
