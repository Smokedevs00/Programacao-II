public class Triangulo {
    private double base;
    private double altura;

  
    public Triangulo(double base, double altura) {
        this.base = base;
        this.altura = altura;
    }

    public double calcularArea() {
        return (base * altura) / 2;
    }

    public double getBase() {
        return base;
    }

   
    public double getAltura() {
        return altura;
    }

    public static void main(String[] args) {
        Triangulo triangulo = new Triangulo(10.0, 7.0);

        
        double area = triangulo.calcularArea();
        System.out.println("A área do triângulo é: " + area);

        double base = triangulo.getBase();
        double altura = triangulo.getAltura();
        System.out.println("Base do triângulo: " + base);
        System.out.println("Altura do triângulo: " + altura);
    }
}
