
public abstract class Shape {
   
    public abstract double area();

    
    public abstract double perimetro();
}


public class Circulo extends Shape {
    private double raio;

    // Construtor
    public Circulo(double raio) {
        this.raio = raio;
    }

    @Override
    public double area() {
        return Math.PI * raio * raio;
    }

    @Override
    public double perimetro() {
        return 2 * Math.PI * raio;
    }
}


public class Retangulo extends Shape {
    private double comprimento;
    private double largura;

    // Construtor
    public Retangulo(double comprimento, double largura) {
        this.comprimento = comprimento;
        this.largura = largura;
    }

    @Override
    public double area() {
        return comprimento * largura;
    }

    @Override
    public double perimetro() {
        return 2 * (comprimento + largura);
    }
}


    public static void main(String[] args) {
        Circulo circulo = new Circulo(5.0);
        Retangulo retangulo = new Retangulo(4.0, 6.0);

        System.out.println("Área do Círculo: " + circulo.area());
        System.out.println("Perímetro do Círculo: " + circulo.perimetro());

        System.out.println("Área do Retângulo: " + retangulo.area());
        System.out.println("Perímetro do Retângulo: " + retangulo.perimetro());
    }

